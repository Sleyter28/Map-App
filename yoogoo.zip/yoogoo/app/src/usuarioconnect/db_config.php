<?php
define('DB_USER', "u890009820_dbusr"); // db user
define('DB_PASSWORD', "s2831994"); // db password (mention your db password here)
define('DB_DATABASE', "u890009820_user"); // database name
define('DB_SERVER', "localhost"); // db server
?>