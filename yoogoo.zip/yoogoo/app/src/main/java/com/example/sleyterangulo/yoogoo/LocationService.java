package com.example.sleyterangulo.yoogoo;

import android.Manifest;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;


/**
 * Created by sleyterangulo on 10/27/16.
 */

public class LocationService extends Service {

    public LocationService() {

    }

    @Override
    public void onCreate() {
        super.onCreate();


        Log.d("MyService", "onStart: " );

        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        mDestination = new Location("9.983620,-84.720754");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) !=
                            PackageManager.PERMISSION_GRANTED) {

            }
        }
        locationManager.removeUpdates(locationListener);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0,
                locationListener);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private Location mDestination;

    private LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {

            Log.d("changed", Double.toString(location.getLatitude()) + "," + Double.toString(location.getLongitude()));

            float distance = mDestination.distanceTo(location);

            float locationTotal = (float) ( 300 * Math.PI);
            //float locationTotal = location * Math.PI;

            if (distance<locationTotal){
//                NotificationCompat.Builder mBuilder =
//                        new NotificationCompat.Builder(LocationService.this)
//                                .setSmallIcon(R.mipmap.ic_launcher)
//                                .setContentTitle("Distance")
//                                .setContentText("Usuario esta dentro del rango");
//                                //.setContentText(Float.toString(distance));
//                NotificationManager mNotificationManager =
//                        (NotificationManager) getSystemService(
//                                Context.NOTIFICATION_SERVICE);
//                mNotificationManager.notify(1, mBuilder.build());
            }
            else{
//                NotificationCompat.Builder mBuilder =
//                        new NotificationCompat.Builder(LocationService.this)
//                                .setSmallIcon(R.mipmap.ic_launcher)
//                                .setContentTitle("Distance")
//                                .setContentText("Usuario esta fuera del rango, su presición: "+ mDestination.getAccuracy());
//                //.setContentText(Float.toString(distance));
//                NotificationManager mNotificationManager =
//                        (NotificationManager) getSystemService(
//                                Context.NOTIFICATION_SERVICE);
//                mNotificationManager.notify(1, mBuilder.build());

            }


        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }


}
